# n8n server — incident snapshot

Captured: 2026-09-03 08:30 UTC
Role of this host: n8n automation (Docker, bound to 127.0.0.1 only, tz Asia/Jakarta).

An analyst noticed a workflow keeping "phoning home" around 16:00 local time.
Before the box was isolated we exported every workflow from n8n, pulled the
process .env file, dumped the container env, and captured tcpdump of the host
(traffic.pcap).

Seven workflows are in workflow_export.json. One of them is NOT normal.

What we know from that night:
  - The host ran n8n 2.30.4, before the 2.31.5 / 2.32.1 sandbox-escape fix
    (GHSA-gv7g-jm28-cr3m).
  - A workflow was saved in the editor a short while before the activity.
  - The n8n/node process briefly spawned a child process shortly after.
  - Seconds later traffic went out from the host.
  - Several outbound callouts were observed, but only one appears to have
    completed.
  - The encryption key the instance used is NOT the one in the .env file;
    it shows up in the capture, but written backwards.
  - We also pulled a PDF copy of the workflow ownership register
    (workflow_owners.pdf), but it came out blank.
  - A raw memory excerpt was captured from the listener that accepted the
    outbound requests (c2-memory.bin).
  - workflow_versions.json contains the saved history of the workflows.

Files:
  workflow_export.json    7 workflows from the n8n instance
  workflow_versions.json  saved version history of the workflows
  workflow_owners.pdf     ownership register - appears blank/empty
  executions.json         execution records from the instance
  audit.log               audit log of workflow changes
  n8n-event-log.json      n8n event log excerpts
  docker-inspect.txt      container environment dump
  .env                    environment file (key rotated during IR)
  traffic.pcap            network capture from the host
  c2-memory.bin           raw memory excerpt from the suspicious listener

Hunt carefully. The flag is not on this box: answer the forensic questions on
the live challenge server (see the briefing) to get it. The server is the only
place the flag exists. Reconstruct the exfiltration from these artifacts.
